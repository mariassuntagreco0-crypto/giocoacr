Versione placeholder del gioco ACR con nuove funzioni da implementare.
